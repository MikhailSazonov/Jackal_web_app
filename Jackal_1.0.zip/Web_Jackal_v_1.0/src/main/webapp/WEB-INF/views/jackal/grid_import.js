import { grid } from '../../../../java/org/example/model/Grid.java'

export function grid_import() {
    return "Hello";
}